import reachability
from isolation import Board

def compute_exitability(width,height,loc):
    game = Board("p1", "p2",7,7)
    reach = reachability.reachability(game,loc)
    print(reach.to_string())
