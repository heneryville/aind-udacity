import itertools
import random
import warnings
import threading

from collections import namedtuple

from isolation import Board
from sample_players import (RandomPlayer, open_move_score,
                            improved_score, center_score)
from game_agent import (MinimaxPlayer, AlphaBetaPlayer, custom_score,
                        custom_score_2, custom_score_3)

NUM_MATCHES = 2  # number of matches against each opponent
TIME_LIMIT = 350  # number of milliseconds before timeout
INSTANCES = 2  # number of game agents that will be initiated

Agent = namedtuple("Agent", ["player", "name"])

def play_round(p1, test_agents, win_counts, num_matches):
    """Compare the test agents to the cpu agent in "fair" matches.

    "Fair" matches use random starting locations and force the agents to
    play as both first and second player to control for advantages resulting
    from choosing better opening moves or having first initiative to move.
    """
    timeout_count = 0
    forfeit_count = 0
    for _ in range(num_matches):

        games = sum([[Board(cpu_agent.player, agent.player),
                      Board(agent.player, cpu_agent.player)]
                    for agent in test_agents], [])

        # initialize all games with a random move and response
        for _ in range(2):
            move = random.choice(games[0].get_legal_moves())
            for game in games:
                game.apply_move(move)

        # play all games and tally the results
        for game in games:
            winner, _, termination = game.play(time_limit=TIME_LIMIT)
            win_counts[winner] += 1

            if termination == "timeout":
                timeout_count += 1
            elif termination == "forfeit":
                forfeit_count += 1

    return timeout_count, forfeit_count


def play_matches():
    g1p1 = Agent(AlphaBetaPlayer(score_fn=custom_score), "AB_Custom")
    g1p2 = Agent(AlphaBetaPlayer(score_fn=custom_score_2), "AB_Custom_2")
    g2p1 = Agent(AlphaBetaPlayer(score_fn=custom_score), "AB_Custom")
    g2p2 = Agent(AlphaBetaPlayer(score_fn=custom_score_2), "AB_Custom_2")

    stats = []
    for _ in range(NUM_MATCHES):
        games = [Board(g1p1.player, g1p2.player), Board(g2p2.player, g2p1.player)]
        for _ in range(2):
            move = random.choice(games[0].get_legal_moves())
            for game in games:
                game.apply_move(move)
        stats.append(play_out_with_stats(games[0],g1p1.player,g1p2.player))
        stats.append(play_out_with_stats(games[1],g2p1.player,g2p2.player))
    return stats

def play_out_with_stats(game,p1,p2):
    winner, moves, termination = game.play(time_limit=TIME_LIMIT)
    winvalue = 1 if p1 == winner else -1
    p1_avg_depth = sum(p1.depths_reached)/len(p1.depths_reached)
    p2_avg_depth = sum(p1.depths_reached)/len(p1.depths_reached)
    return (winvalue,len(moves),termination,p1_avg_depth,p2_avg_depth)

def handler(event,context):
    stats = play_matches()
    return stats

local_results = []
def handler_local():
    stats = handler({},{})
    local_results.extend(stats)

def swarm_local():
    threads = [ threading.Thread(target=handler_local, args=(), kwargs={}) for x in range(INSTANCES) ]
    for thread in threads: thread.start()
    for thread in threads: thread.join()
    print(local_results)

def swarm_aws():
    threads = [ threading.Thread(target=handler_local, args=(), kwargs={}) for x in range(INSTANCES) ]
    for thread in threads: thread.start()
    for thread in threads: thread.join()
    print(local_results)

def main():

    swarm_local()
    return

    # Define two agents to compare -- these agents will play from the same
    # starting position against the same adversaries in the tournament
    test_agents = [
        #Agent(AlphaBetaPlayer(score_fn=improved_score), "AB_Improved"),
        Agent(AlphaBetaPlayer(score_fn=custom_score), "AB_Custom"),
        Agent(AlphaBetaPlayer(score_fn=custom_score_2), "AB_Custom_2"),
        #Agent(AlphaBetaPlayer(score_fn=custom_score_3), "AB_Custom_3")
    ]

    # Define a collection of agents to compete against the test agents
    cpu_agents = [
        #Agent(RandomPlayer(), "Random"),
        #Agent(MinimaxPlayer(score_fn=open_move_score), "MM_Open"),
        #Agent(MinimaxPlayer(score_fn=center_score), "MM_Center"),
        #Agent(MinimaxPlayer(score_fn=improved_score), "MM_Improved"),
        #Agent(AlphaBetaPlayer(score_fn=open_move_score), "AB_Open"),
        #Agent(AlphaBetaPlayer(score_fn=center_score), "AB_Center"),
        Agent(AlphaBetaPlayer(score_fn=improved_score), "AB_Improved")
    ]

    print(DESCRIPTION)
    print("{:^74}".format("*************************"))
    print("{:^74}".format("Playing Matches"))
    print("{:^74}".format("*************************"))
    play_matches(cpu_agents, test_agents, NUM_MATCHES)


if __name__ == "__main__":
    main()
