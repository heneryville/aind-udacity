ls *.py | entr -c python 'agent_test.py'
